// p5js button library
// click the circles to change their colors
// press the buttons at the top, to manipulate the falling circles
// buttons will do something according to their names


let button1;
let button2;
let button3;
let button4;

function setup() {
  createCanvas(500, 800);
  
  x = [];
  y = [];
  c = [];
  d = 50;
  // c = 1 meaning the color is red
  // c = 2 meaning the color is blue
  
  for (i = 0; i < 10; i++){
    x[i] = random(10, 500);
    y[i] = random(350, 100);
    c[i] = 1;
  }
  
  button1 = createButton('click me');
  button2 = createButton('maybe click me');
  button3 = createButton('dont click me');
  button4 = createButton('[error]');
  
  // click me
  button1.position(25,10);
  button1.mousePressed(doSomethingGood);
  
  // maybe click me
  button2.position(100,10);
  button2.mousePressed(doSomethingAlright);
  
  // dont click me
  button3.position(375,10);
  button3.mousePressed(doSomethingBad);
  
  // [error]
  button4.position(300,10);
  button4.mousePressed(saySomething);
 
  
}

function doSomethingGood(){
  d = 75;
}

function doSomethingAlright(){
  textSize(50);
  fill('purple');
  text('buh xD', 250,400);
}

function doSomethingBad(){
  d = 10;
}


// prints error message when button is pressed
function saySomething(){
   fill('lime');
   rect(0,0,473,473);
  print("Probably shouldn't have pressed that...");
  c = 1;
}

function draw() {
  background('black');
  
  for (i = 0; i < 10; i++){
    if (c[i] == 1) fill(255, 0, 0);
    if (c[i] == 2) fill(0, 0, 255);
    y[i] = y[i]+2;
    
    circle(x[i],y[i],d);
  }
}

  
  
function mouseClicked() {
  for (i = 0; i < 10; i++){
    if (dist(mouseX, mouseY, x[i], y[i]) < d/2){
      if (c[i] == 2) {
        c[i] = 1; // if 1, allows user to reset the color by pressing again
                  // if 2, doesnt allow user to reset the color
      } else {
        c[i] = 2;
      }
    }
  }
}
