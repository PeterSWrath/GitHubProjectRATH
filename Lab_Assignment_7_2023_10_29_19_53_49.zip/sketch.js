// theme weather -
// 400x400 -
// create a function that uses translate() -
// for loops()
// scale() -
// rotate() -
// angleMode()
// push() and pop() -
// create a function that uses print()



let shapes = [];
let rainyLevel;

function setup() {
  createCanvas(600,600);
  
}

function draw() {
  background('lightblue');
  
   //ground
  fill('green');
  rect(0,580,600,580)

   //clouds
  cloud(1,90);
  cloud(270,50);
  
  scale(0.75);
  cloud(4,55);
  
  // placement of the raindrops
  
  for(let shape of shapes) {
    push();
    fill(shape.color)
    shape.y += 5;
      ellipse(shape.x, shape.y, 10, 20);
  
  
    pop();
  }
}

// adds raindrops


function mousePressed() {
  addRainDrop();

}

// creates the raindrops

function addRainDrop() {
  drop1 = {
    x: mouseX,
    y: mouseY,
    color: random(['blue']),
    shapeType: random(['ellipse'])
  }
  shapes.push(drop1);
}

// creates clouds

function cloud(x,y){
  push();
  
  translate(x,y);
  
  strokeWeight(0);
  fill('white');
  ellipse(175,175,175,175);
  ellipse(120,200,135,100);
  ellipse(200,150,205,90);
  
  pop();
}
