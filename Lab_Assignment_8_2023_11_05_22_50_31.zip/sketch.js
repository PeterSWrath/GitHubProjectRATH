/*
400x400
IMAGES
load 2  images and assign a variable to each image using a preload function
mouseX and mouseY to change the images location or image size
transparent .gif or .png file and assign a variable to the image using the preload function
mouseX and/or mouseY variables to change the images lovation

TEXT
text function();
textFont function();
change the stroke and fill for the text that is created with the text function
*/



//creates new gif var
var gif_loadImg, gif_createImg;

//var for mouse x and y
var x;
var y;

// position for dragged image
var imageX = 100;
var imageY = 100;

var img;

function preload() {
 
  img = loadImage('https://fastly.picsum.photos/id/15/200/200.jpg?hmac=8F3A7g2kO57xRlUcdio-9o4LDz0oEFZrYMldJkHMpVo');
  
  
  //gif(lines 36,37) dont work, and im not sure why
  //gif_loadImg = loadImage('https://tenor.com/view/random-gif-10066912');
  //gif_createImg = createImg('https://tenor.com/view/random-gif-10066912');

}

//function that lets you move the image

function mouseDragged() {
  if ((mouseX > imageX - 50) && (mouseX < imageX + 50)){
    if ((mouseY > imageY - 50) && (mouseY < imageY + 50)){
      imageX = mouseX;
      imageY = mouseY;
    }
  }
}




function setup() {
  createCanvas(500, 500);

}


function draw() {
  background(100); // have background in draw() so image is removed constantly, and doesnt make duplicates
  fill('palegreen');
  textFont('Courier New');
  textSize(24);
  text('drag the image around', 65, 35);
  
  
   image(img, imageX, imageY, 50, 50);
  
  //supposed to create the new gif image, doesnt
  //gif_createImg.position(100,100);
  

}

